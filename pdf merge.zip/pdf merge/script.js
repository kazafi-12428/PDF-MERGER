// Initialize PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.11.338/pdf.worker.min.js';

let pdfFiles = [];
let mergedPdfUrl = null;

document.getElementById('pdf-files').addEventListener('change', handleFileUpload);
document.getElementById('merge-btn').addEventListener('click', mergePDFs);
document.getElementById('download-btn').addEventListener('click', downloadMergedPDF);

// Handle PDF upload + preview
async function handleFileUpload(e) {
    const files = Array.from(e.target.files);
    if (files.length < 2) {
        alert("Please select at least 2 PDF files!");
        return;
    }

    pdfFiles = [];
    const preview = document.getElementById('pdf-preview');
    preview.innerHTML = '';

    for (const file of files) {
        const pdfItem = document.createElement('div');
        pdfItem.className = 'pdf-item';

        // Add thumbnail preview
        const thumbnail = document.createElement('div');
        thumbnail.className = 'pdf-thumbnail';
        thumbnail.textContent = 'Loading preview...';
        pdfItem.appendChild(thumbnail);

        // Add file name
        const fileName = document.createElement('span');
        fileName.textContent = file.name;
        pdfItem.appendChild(fileName);

        // Add reorder/delete buttons
        const controls = document.createElement('div');
        controls.className = 'pdf-controls';

        const upBtn = document.createElement('button');
        upBtn.textContent = '↑';
        upBtn.onclick = () => movePDFUp(file);
        controls.appendChild(upBtn);

        const downBtn = document.createElement('button');
        downBtn.textContent = '↓';
        downBtn.onclick = () => movePDFDown(file);
        controls.appendChild(downBtn);

        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = '×';
        deleteBtn.onclick = () => removePDF(file);
        controls.appendChild(deleteBtn);

        pdfItem.appendChild(controls);
        preview.appendChild(pdfItem);

        // Generate thumbnail
        try {
            const arrayBuffer = await file.arrayBuffer();
            const pdf = await pdfjsLib.getDocument(arrayBuffer).promise;
            const page = await pdf.getPage(1);
            const viewport = page.getViewport({ scale: 0.2 });

            const canvas = document.createElement('canvas');
            const context = canvas.getContext('2d');
            canvas.height = viewport.height;
            canvas.width = viewport.width;

            await page.render({
                canvasContext: context,
                viewport: viewport
            }).promise;

            thumbnail.innerHTML = '';
            thumbnail.appendChild(canvas);
        } catch (error) {
            thumbnail.textContent = 'Preview unavailable';
        }

        pdfFiles.push(file);
    }
}

// Reorder PDFs
function movePDFUp(file) {
    const index = pdfFiles.indexOf(file);
    if (index > 0) {
        [pdfFiles[index], pdfFiles[index - 1]] = [pdfFiles[index - 1], pdfFiles[index]];
        updatePreview();
    }
}

function movePDFDown(file) {
    const index = pdfFiles.indexOf(file);
    if (index < pdfFiles.length - 1) {
        [pdfFiles[index], pdfFiles[index + 1]] = [pdfFiles[index + 1], pdfFiles[index]];
        updatePreview();
    }
}

function removePDF(file) {
    pdfFiles = pdfFiles.filter(f => f !== file);
    updatePreview();
}

function updatePreview() {
    // Simulate a new file upload to refresh the preview
    const input = document.getElementById('pdf-files');
    const dataTransfer = new DataTransfer();
    pdfFiles.forEach(file => dataTransfer.items.add(file));
    input.files = dataTransfer.files;
    input.dispatchEvent(new Event('change'));
}

// Merge PDFs
async function mergePDFs() {
    if (pdfFiles.length < 2) {
        alert("Please select at least 2 PDF files!");
        return;
    }

    const status = document.getElementById('status');
    status.textContent = "Merging PDFs...";

    try {
        const { PDFDocument } = PDFLib;
        const mergedPdf = await PDFDocument.create();

        for (const file of pdfFiles) {
            const fileData = await file.arrayBuffer();
            const pdfDoc = await PDFDocument.load(fileData);
            const pages = await mergedPdf.copyPages(pdfDoc, pdfDoc.getPageIndices());
            pages.forEach(page => mergedPdf.addPage(page));
        }

        const mergedPdfBytes = await mergedPdf.save();
        const blob = new Blob([mergedPdfBytes], { type: 'application/pdf' });
        mergedPdfUrl = URL.createObjectURL(blob);

        document.getElementById('download-btn').disabled = false;
        status.textContent = "PDFs merged successfully! Click 'Download' to save.";
    } catch (error) {
        status.textContent = "Error merging PDFs: " + error.message;
    }
}

// Download merged PDF
function downloadMergedPDF() {
    if (!mergedPdfUrl) return;
    const a = document.createElement('a');
    a.href = mergedPdfUrl;
    a.download = 'merged.pdf';
    a.click();
}